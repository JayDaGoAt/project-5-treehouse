$(".nav-icon").on("click", function(e){
	e.preventDefault();
	$(".nav li").slideToggle();
});



